// src/app/page.tsx

export default function Home() {
    return (
        <div className="text-center text-2xl font-bold mt-10 text-black">
            ToDoTogether에 오신 걸 환영합니다!
        </div>
    );
}
